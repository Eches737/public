#!/usr/bin/env python3
"""Run toc_scrape_and_upload.py for top N TOCs from selected_tocs.json and upload PDFs to Azure.

Defaults: top 5 TOCs, up to 20 articles per TOC (conservative). Logs are appended to toc_upload_run.log.
"""
import json
import subprocess
from pathlib import Path
import argparse
import datetime

parser = argparse.ArgumentParser(description='Run TOC upload for selected TOCs')
parser.add_argument('--count', type=int, default=5, help='Number of top TOCs to process')
parser.add_argument('--per-toc-max', type=int, default=20, help='Max articles to attempt per TOC')
parser.add_argument('--container', default='doaj-pdfs')
parser.add_argument('--connection-string', default=None)
parser.add_argument('--start-index', type=int, default=0, help='Start index into selected_tocs.json (0-based)')
args = parser.parse_args()

root = Path(__file__).parent
p = root / 'selected_tocs.json'
logf = root / 'toc_upload_run.log'
python_exe = Path(__file__).parent.parent / '.venv' / 'Scripts' / 'python.exe'

if not p.exists():
    print('selected_tocs.json not found at', p)
    raise SystemExit(1)

with p.open('r', encoding='utf-8') as fh:
    arr = json.load(fh)

end_index = min(len(arr), args.start_index + args.count)
items = arr[args.start_index:end_index]

if args.connection_string is None:
    # try environment
    import os
    args.connection_string = os.environ.get('AZURE_STORAGE_CONNECTION_STRING')

if not args.connection_string:
    print('Azure connection string not provided via --connection-string or AZURE_STORAGE_CONNECTION_STRING env. Aborting.')
    raise SystemExit(2)

with logf.open('a', encoding='utf-8') as lfh:
    lfh.write(f"\n===== START RUN {datetime.datetime.utcnow().isoformat()} UTC count={len(items)} per_toc_max={args.per_toc_max} =====\n")

for i, rec in enumerate(items, args.start_index+1):
    toc = rec.get('doaj_toc')
    title = rec.get('title')
    print(f'[{i}] Processing TOC: {title} -> {toc}')
    with logf.open('a', encoding='utf-8') as lfh:
        lfh.write(f"\n--- TOC {i}: {title} -> {toc} ---\n")
    cmd = [str(python_exe), str(root / 'toc_scrape_and_upload.py'), '--toc-url', toc, '--max', str(args.per_toc_max), '--container', args.container, '--connection-string', args.connection_string]
    # run and append output to log
    with logf.open('a', encoding='utf-8') as lfh:
        lfh.write('CMD: ' + ' '.join(cmd) + '\n')
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True)
        for line in proc.stdout:
            print(line, end='')
            lfh.write(line)
        proc.wait()
        lfh.write(f"TOC {i} exitcode={proc.returncode}\n")

with logf.open('a', encoding='utf-8') as lfh:
    lfh.write(f"===== END RUN {datetime.datetime.utcnow().isoformat()} UTC =====\n")

print('Done')
