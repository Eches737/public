import os
import logging
from importlib.machinery import SourceFileLoader
from pathlib import Path

# Load the fixed module as a proper module to call its functions directly
module_path = os.path.join(os.path.dirname(__file__), 'download_and_upload_fixed.py')
mod = SourceFileLoader('doaj_fixed', module_path).load_module()

# Setup logging DEBUG
mod.setup_logging(logging.DEBUG)

# Parameters
QUERY = 'journal:plos'
CONTAINER = 'doaj-pdfs'
MAX = 10
DELAY = 1.0
DRY_RUN = False
AZ_CONN = os.environ.get('AZURE_STORAGE_CONNECTION_STRING')
if not AZ_CONN and not DRY_RUN:
    print('No AZURE_STORAGE_CONNECTION_STRING in env; aborting')
    raise SystemExit(1)

session = mod.requests.Session()
mod.Retry = mod.Retry  # ensure attribute exists
retry = mod.Retry(total=5, backoff_factor=1, status_forcelist=[429,500,502,503,504], allowed_methods=["HEAD","GET","OPTIONS"])
session.mount('https://', mod.HTTPAdapter(max_retries=retry))
session.mount('http://', mod.HTTPAdapter(max_retries=retry))

# Fetch records
print('Searching DOAJ...')
records = []
for rec in mod.search_doaj(QUERY, page_size=20, max_results=MAX, session=session):
    records.append(rec)
print('Found', len(records), 'records; processing sequentially')

tmp_dir = Path('./tmp_downloads')
tmp_dir.mkdir(parents=True, exist_ok=True)

class SimpleQ:
    def __init__(self):
        self.items = []
    def put(self, item):
        self.items.append(item)

for idx, rec in enumerate(records, start=1):
    print('\n=== RECORD', idx, '===')
    q = SimpleQ()
    params = {'dry_run': DRY_RUN, 'connection_string': AZ_CONN, 'container': CONTAINER, 'delay': DELAY}
    try:
        mod.record_worker(rec, idx, params, str(tmp_dir), q)
    except Exception as e:
        print('record_worker raised', e)
    if q.items:
        for it in q.items:
            print('RESULT:', it)
    else:
        print('No result reported for record', idx)

print('\nDone')
