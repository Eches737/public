#!/usr/bin/env python3
"""Simple arXiv PDF downloader.

Usage examples:
  python doaj_downloader/download_arxiv.py --ids 2101.00001
  python doaj_downloader/download_arxiv.py --file ids.txt --out-dir ./downloads/arxiv
  python doaj_downloader/download_arxiv.py --ids 2101.00001,2001.00002 --dry-run

The script streams PDF files to disk with retries and a sane timeout.
"""
from __future__ import annotations

import argparse
import logging
import os
import re
import sys
from pathlib import Path
from typing import Iterable

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

USER_AGENT = "scoutpaper-arxiv-downloader/1.0 (+https://github.com/Eches737/scoutpaper)"


def setup_logging(level: int = logging.INFO) -> None:
    logging.basicConfig(
        format="%(asctime)s %(levelname)-5s %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        level=level,
    )


def make_session(timeout: int = 15) -> requests.Session:
    s = requests.Session()
    s.headers.update({"User-Agent": USER_AGENT})
    retries = Retry(
        total=5,
        backoff_factor=0.5,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=("GET", "HEAD"),
    )
    adapter = HTTPAdapter(max_retries=retries)
    s.mount("https://", adapter)
    s.mount("http://", adapter)
    # attach a simple timeout wrapper via request args when calling
    s.request = lambda *a, **kw: requests.Session.request(s, *a, timeout=timeout, **kw)
    return s


def sanitize_filename(s: str) -> str:
    # Keep common safe chars, replace others with underscore
    s = s.strip()
    s = re.sub(r"[\\/]+", "-", s)
    s = re.sub(r"[^0-9A-Za-z.\- _()]+", "_", s)
    return s


def arxiv_pdf_url(arxiv_id: str) -> str:
    # Accept already-normalized ids (with version if present)
    return f"https://arxiv.org/pdf/{arxiv_id}.pdf"


def download_pdf(arxiv_id: str, out_dir: Path, session: requests.Session, dry_run: bool = False) -> Path | None:
    url = arxiv_pdf_url(arxiv_id)
    out_dir.mkdir(parents=True, exist_ok=True)
    filename = sanitize_filename(arxiv_id) + ".pdf"
    out_path = out_dir / filename

    logging.info("Downloading %s → %s", url, out_path)
    if dry_run:
        logging.info("Dry-run: not performing network request for %s", arxiv_id)
        return out_path

    try:
        resp = session.get(url, allow_redirects=True, stream=True)
    except Exception as e:
        logging.error("Request failed for %s: %s", arxiv_id, e)
        return None

    if resp.status_code != 200:
        logging.error("Non-200 response for %s: %s", arxiv_id, resp.status_code)
        return None

    content_type = resp.headers.get("Content-Type", "")
    if "pdf" not in content_type and not str(resp.url).lower().endswith(".pdf"):
        logging.warning("Content-Type for %s is %s (expected PDF). Proceeding to save but check file.", arxiv_id, content_type)

    try:
        tmp_path = out_path.with_suffix(".part")
        with tmp_path.open("wb") as fh:
            for chunk in resp.iter_content(chunk_size=1024 * 128):
                if not chunk:
                    continue
                fh.write(chunk)
        tmp_path.replace(out_path)
        logging.info("Saved %s", out_path)
        return out_path
    except Exception as e:
        logging.error("Failed saving %s: %s", arxiv_id, e)
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass
        return None


def ids_from_file(path: Path) -> Iterable[str]:
    with path.open("r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # allow comma-separated in-line
            for part in re.split(r"[\s,]+", line):
                if part:
                    yield part


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="arXiv PDF downloader")
    p.add_argument("--ids", help="Comma-separated arXiv IDs (e.g. 2101.00001,2001.00002)")
    p.add_argument("--file", type=Path, help="File with arXiv IDs, one per line")
    p.add_argument("--out-dir", type=Path, default=Path("./downloads/arxiv"), help="Output directory")
    p.add_argument("--dry-run", action="store_true", help="Show what would be downloaded but don't perform network calls")
    p.add_argument("--timeout", type=int, default=20, help="Per-request timeout (seconds)")
    p.add_argument("--max", type=int, default=0, help="Max number of IDs to process (0 = all)")
    p.add_argument("--verbose", action="store_true")
    return p.parse_args()


def main() -> int:
    args = parse_args()
    setup_logging(logging.DEBUG if args.verbose else logging.INFO)

    # gather ids
    ids: list[str] = []
    if args.ids:
        for part in re.split(r"[\s,]+", args.ids):
            if part:
                ids.append(part)
    if args.file:
        ids.extend(list(ids_from_file(args.file)))

    if not ids:
        logging.error("No arXiv IDs provided. Use --ids or --file.")
        return 2

    if args.max > 0:
        ids = ids[: args.max]

    session = make_session(timeout=args.timeout)

    successes = 0
    failures = 0
    for aid in ids:
        out = download_pdf(aid, args.out_dir, session, dry_run=args.dry_run)
        if out:
            successes += 1
        else:
            failures += 1

    logging.info("Done. success=%d fail=%d", successes, failures)
    return 0 if failures == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
