$monitor = Join-Path (Get-Location) 'doaj_downloader\doaj_monitor.log'
$pub = Join-Path (Get-Location) 'doaj_downloader\doaj_monitor_pub.log'
$interval = 60
"Publish monitor started at $(Get-Date -Format s)" | Out-File -FilePath $pub -Encoding utf8 -Append
while ($true) {
    if (Test-Path $monitor) {
        try {
            $lines = Get-Content $monitor -ErrorAction Stop
            if ($lines.Count -gt 0) {
                $last = $lines[-1]
                $stamp = Get-Date -Format s
                "$stamp $last" | Out-File -FilePath $pub -Append -Encoding utf8
            }
        } catch {
            # ignore read errors
        }
    }
    Start-Sleep -Seconds $interval
}
