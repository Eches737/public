﻿## start_downloader_wrapper.ps1
# Load AZURE connection string from HKCU and run the TOC uploader from the doaj_downloader folder.
$envKey = 'HKCU:\Environment'
$az = (Get-ItemProperty -Path $envKey -Name 'AZURE_STORAGE_CONNECTION_STRING' -ErrorAction SilentlyContinue).AZURE_STORAGE_CONNECTION_STRING
if ($az) { [Environment]::SetEnvironmentVariable('AZURE_STORAGE_CONNECTION_STRING',$az,'Process') }

# Ensure we run from the script's dir (doaj_downloader)
$wd = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location -Path $wd

# Prefer the virtualenv python if present
$venv = Join-Path $wd '.venv\Scripts\python.exe'
if (-not (Test-Path $venv)) { $venv = 'python' }

# Run the CSV-based TOC upload driver (outputs appended to toc_upload_run.log)
## Start uploader in a new background process and write to a timestamped log to avoid file locks
$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
$logFile = "toc_upload_run_$ts.log"
$args = @('run_selected_tocs_upload.py','--count','5','--per-toc-max','20')

# Use cmd.exe to run the python command so the shell handles redirection (works around Start-Process redirect limitations)
 $cmdLine = '"' + $venv + '" run_selected_tocs_upload.py --count 5 --per-toc-max 20 >> "' + $logFile + '" 2>&1'
Start-Process -FilePath 'cmd.exe' -ArgumentList '/c', $cmdLine -WorkingDirectory $wd -WindowStyle Hidden

Write-Host "Started background uploader (via cmd). Log: $wd\$logFile"
