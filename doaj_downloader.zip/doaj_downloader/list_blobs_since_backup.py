import os
import datetime
from azure.storage.blob import BlobServiceClient

# 백업 시각 (파일명에 사용된 타임스탬프)
backup_ts = '20251108T051502'
# 파싱: YYYYMMDDTHHMMSS
cutoff = datetime.datetime.strptime(backup_ts, '%Y%m%dT%H%M%S')
# 비교를 위해 naive UTC 시간을 사용 (blob.last_modified을 UTC로 변환 후 tzinfo 제거)

conn = os.environ.get('AZURE_STORAGE_CONNECTION_STRING')
if not conn:
    print('NO_CONN')
    raise SystemExit(1)

container = 'doaj-pdfs'
bs = BlobServiceClient.from_connection_string(conn)
cc = bs.get_container_client(container)

print('CUTOFF (parsed from backup):', cutoff.isoformat())
found = 0
for b in cc.list_blobs():
    lm = b.last_modified
    if not lm:
        continue
    if lm.tzinfo is not None:
        lm_utc = lm.astimezone(datetime.timezone.utc).replace(tzinfo=None)
    else:
        lm_utc = lm
    if lm_utc >= cutoff:
        print(lm_utc.isoformat(), b.name)
        found += 1
print('FOUND', found)
