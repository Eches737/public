#!/usr/bin/env python3
"""Deep-traverse a TOC page (depth-limited crawl) to discover PDF URLs and upload them to Azure.

Behavior:
 - BFS from the TOC URL, follow links up to depth `max_depth` (TOC is depth 0).
 - For each visited URL, check HEAD for PDF; if not, GET the page and extract hrefs to enqueue.
 - Stop when `max_pdfs` uploaded (per TOC) or `max_pages` visited.
 - Uses `safe_get`, `safe_head`, `download_to_file`, `upload_blob` from `download_and_upload.py`.
 - Conservative defaults to avoid runaway crawling.
"""

import logging
import os
import re
import time
from collections import deque
from pathlib import Path
from urllib.parse import urljoin, urlparse

from download_and_upload import safe_get, safe_head, download_to_file, upload_blob, HEADERS

LOG = logging.getLogger('doaj_deep')

PDF_RE = re.compile(r"\.pdf($|\?)", flags=re.I)
HREF_RE = re.compile(r'href=["\']([^"\']+)["\']', flags=re.I)


def extract_hrefs(html: str):
    return HREF_RE.findall(html)


def is_pdf_url(url: str):
    return bool(PDF_RE.search(url))


def traverse_and_upload(toc_url: str, max_pdfs: int = 5, max_pages: int = 200, max_depth: int = 2, container: str = 'doaj-pdfs', connection_string: str = None, dry_run: bool = False):
    session = None
    try:
        import requests
        session = requests.Session()
    except Exception:
        session = None

    q = deque()
    q.append((toc_url, 0))
    visited = set()
    uploaded = []
    tmp_dir = Path('./tmp_downloads')
    tmp_dir.mkdir(parents=True, exist_ok=True)

    pages_visited = 0

    start_time = time.time()

    while q and len(uploaded) < max_pdfs and pages_visited < max_pages:
        url, depth = q.popleft()
        if url in visited:
            continue
        visited.add(url)

        LOG.debug('Visiting (%s) depth=%s', url, depth)
        pages_visited += 1

        # 1) quick HEAD to see if it's a direct PDF
        try:
            head = safe_head(session, url, headers=HEADERS, allow_redirects=True, timeout=10)
            if head is not None:
                ctype = head.headers.get('Content-Type', '')
                final = getattr(head, 'url', url)
                if 'pdf' in ctype.lower() or is_pdf_url(final):
                    LOG.info('HEAD shows PDF: %s', final)
                    local_name = Path(final).name or 'file.pdf'
                    local = tmp_dir / local_name
                    ok = download_to_file(session, final, local)
                    if ok:
                        if not dry_run and connection_string:
                            if upload_blob(connection_string, container, local.name, local):
                                uploaded.append({'pdf_url': final, 'blob': local.name})
                                try:
                                    local.unlink(missing_ok=True)
                                except Exception:
                                    pass
                        else:
                            uploaded.append({'pdf_url': final, 'blob': None})
                        # continue if we've reached max
                        if len(uploaded) >= max_pdfs:
                            break
                    # if download failed, continue to next link
        except Exception as e:
            LOG.debug('HEAD error for %s: %s', url, e)

        # 2) GET page and look for pdf links / links to follow
        try:
            r = safe_get(session, url, headers=HEADERS, timeout=15, allow_redirects=True)
            if r is None:
                continue
            try:
                r.raise_for_status()
            except Exception:
                html = getattr(r, 'text', '')
            else:
                html = r.text

            # look for direct .pdf hrefs first
            hrefs = extract_hrefs(html)
            # normalize and dedupe
            norm_hrefs = []
            for h in hrefs:
                if not h:
                    continue
                full = urljoin(url, h)
                if full in visited:
                    continue
                norm_hrefs.append(full)

            # prioritize pdf links
            for nh in norm_hrefs:
                if len(uploaded) >= max_pdfs:
                    break
                if is_pdf_url(nh):
                    LOG.info('Found .pdf link: %s', nh)
                    local_name = Path(nh).name or 'file.pdf'
                    local = tmp_dir / local_name
                    ok = download_to_file(session, nh, local)
                    if ok:
                        if not dry_run and connection_string:
                            if upload_blob(connection_string, container, local.name, local):
                                uploaded.append({'pdf_url': nh, 'blob': local.name})
                                try:
                                    local.unlink(missing_ok=True)
                                except Exception:
                                    pass
                        else:
                            uploaded.append({'pdf_url': nh, 'blob': None})
                        if len(uploaded) >= max_pdfs:
                            break

            if len(uploaded) >= max_pdfs:
                break

            # enqueue non-pdf links if depth < max_depth
            if depth < max_depth:
                # limit enqueueing to avoid explosion
                enq_count = 0
                for nh in norm_hrefs:
                    if enq_count >= 200:
                        break
                    if nh in visited:
                        continue
                    # avoid mailto/tel/javascript
                    if nh.startswith('mailto:') or nh.startswith('javascript:') or nh.startswith('tel:'):
                        continue
                    q.append((nh, depth + 1))
                    enq_count += 1

        except Exception as e:
            LOG.debug('GET error for %s: %s', url, e)
            continue

    elapsed = time.time() - start_time
    LOG.info('Traverse complete for %s: pages_visited=%s, uploaded=%s, elapsed=%.1fs', toc_url, pages_visited, len(uploaded), elapsed)
    return uploaded


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='Deep traverse TOC to find PDFs and upload')
    parser.add_argument('--toc-url', required=True)
    parser.add_argument('--max', type=int, default=5)
    parser.add_argument('--max-pages', type=int, default=200)
    parser.add_argument('--max-depth', type=int, default=2)
    parser.add_argument('--container', default='doaj-pdfs')
    parser.add_argument('--connection-string', default=os.environ.get('AZURE_STORAGE_CONNECTION_STRING'))
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')

    if not args.connection_string and not args.dry_run:
        LOG.error('Azure connection string required unless --dry-run')
        raise SystemExit(1)

    res = traverse_and_upload(args.toc_url, max_pdfs=args.max, max_pages=args.max_pages, max_depth=args.max_depth, container=args.container, connection_string=args.connection_string, dry_run=args.dry_run)
    for r in res:
        print(r)
