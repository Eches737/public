#!/usr/bin/env python3
"""Run toc_scrape_and_upload.py in --dry-run for top N TOCs from selected_tocs.json."""
import json
import subprocess
from pathlib import Path

p = Path(__file__).parent / 'selected_tocs.json'
if not p.exists():
    print('selected_tocs.json not found at', p)
    raise SystemExit(1)

with p.open('r', encoding='utf-8') as fh:
    arr = json.load(fh)

N = 5
print(f'Running top {N} TOCs in dry-run')
for i, rec in enumerate(arr[:N], 1):
    toc = rec.get('doaj_toc')
    title = rec.get('title')
    print('\n---')
    print(f'TOC {i}: {title} -> {toc}')
    cmd = [str(Path(__file__).parent.parent / '.venv' / 'Scripts' / 'python.exe'), str(Path(__file__).parent / 'toc_scrape_and_upload.py'), '--toc-url', toc, '--max', '5', '--dry-run']
    print('CMD:', ' '.join(cmd))
    subprocess.run(cmd)

print('\nDone')
