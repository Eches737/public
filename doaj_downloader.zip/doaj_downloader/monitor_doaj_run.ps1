$log = Join-Path (Get-Location) 'doaj_downloader\doaj_run_10000.log'
$out = Join-Path (Get-Location) 'doaj_downloader\doaj_monitor.log'
"Monitor started at $(Get-Date -Format s)" | Out-File -FilePath $out -Encoding utf8 -Append
while ($true) {
    if (Test-Path $log) {
        try {
            $c = Get-Content $log -Raw -ErrorAction Stop
        } catch {
            $c = ""
        }
        $processed = ([regex]::Matches($c,'Processing\s+\d+\/\d+\s+\(record idx\s+\d+\)')).Count
        $uploaded = ([regex]::Matches($c,'Uploaded blob ')).Count
        $no_pdf = ([regex]::Matches($c,'No PDF URL found for record idx')).Count
        $download_failed = ([regex]::Matches($c,'Download failed for record idx')).Count
        $upload_failed = ([regex]::Matches($c,'Upload failed for record idx')).Count
        $skipped_not_pdf = ([regex]::Matches($c,'Skipping upload for')).Count
        $timeouts = ([regex]::Matches($c,'Skipped record idx \d+ due to timeout')).Count
        $line = "$(Get-Date -Format s) processed=$processed uploaded=$uploaded no_pdf=$no_pdf download_failed=$download_failed upload_failed=$upload_failed skipped_not_pdf=$skipped_not_pdf timeouts=$timeouts"
        $line | Out-File -FilePath $out -Append -Encoding utf8
    }
    Start-Sleep -Seconds 60
}
