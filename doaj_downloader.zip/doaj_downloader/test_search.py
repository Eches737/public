import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from download_and_upload_fixed import search_doaj
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

s = requests.Session()
retry = Retry(total=2, backoff_factor=0.5, status_forcelist=[429,500,502,503,504])
s.mount('https://', HTTPAdapter(max_retries=retry))
s.mount('http://', HTTPAdapter(max_retries=retry))

count = 0
for rec in search_doaj('journal:plos', page_size=20, max_results=3, session=s):
    print('RECORD:', rec.get('id') or rec.get('bibjson',{}).get('title'))
    count += 1
print('TOTAL_RECORDS:', count)
