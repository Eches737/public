#!/usr/bin/env python3
"""Simple DOAJ PDF downloader and Azure uploader (clean fixed copy).

This is a compact, cleaned-up implementation intended to be syntactically
valid and safe to run as a replacement. It supports --dry-run and an optional
per-record timeout implemented by launching a short-lived worker process.
"""

import argparse
import hashlib
import logging
import os
import re
import sys
import time
from pathlib import Path
from typing import Generator, Optional
from urllib.parse import quote_plus

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import threading
from collections import deque

try:
    from azure.storage.blob import BlobServiceClient, ContentSettings
except Exception:
    BlobServiceClient = None
    ContentSettings = None

import multiprocessing

LOG = logging.getLogger("doaj_downloader")
DOAJ_SEARCH_ENDPOINT = "https://doaj.org/api/v2/search/articles"
HEADERS = {"User-Agent": "doaj-downloader/2.0 (+https://github.com/your-repo)"}
# Tunables (can be overridden via environment)
# Per-request default read/connect timeout (seconds)
DEFAULT_REQ_TIMEOUT = int(os.environ.get("DOAJ_REQ_TIMEOUT", "60"))
# Retry policy defaults
RETRY_TOTAL = int(os.environ.get("DOAJ_RETRY_TOTAL", "6"))
RETRY_BACKOFF = float(os.environ.get("DOAJ_RETRY_BACKOFF", "2"))


def setup_logging(level=logging.INFO):
    logging.basicConfig(level=level, format="%(asctime)s %(levelname)s: %(message)s")


# Simple rate limiter + safe request helper to avoid triggering DOAJ rate limits.
class RateLimiter:
    """Token-bucket like limiter that enforces both requests-per-second and requests-per-minute.

    It is intentionally conservative. Values can be tuned via environment variables:
    DOAJ_RPS and DOAJ_RPM.
    """
    def __init__(self, rps: float = None, rpm: int = None):
        # defaults: conservative per-user guidance
        try:
            env_rps = os.environ.get("DOAJ_RPS")
            env_rpm = os.environ.get("DOAJ_RPM")
            self.rps = float(env_rps) if env_rps else (float(rps) if rps else 1.0)
            self.rpm = int(env_rpm) if env_rpm else (int(rpm) if rpm else 80)
        except Exception:
            self.rps = 1.0
            self.rpm = 80

        self._lock = threading.Lock()
        self._recent = deque()  # timestamps of recent requests (for per-minute window)
        self._last_req = 0.0

    def wait(self):
        """Block until performing the next request is allowed under both RPS and RPM."""
        with self._lock:
            now = time.monotonic()
            # enforce per-second spacing
            min_interval = 1.0 / max(self.rps, 0.0001)
            since_last = now - self._last_req
            if since_last < min_interval:
                to_sleep = min_interval - since_last
                time.sleep(to_sleep)
                now = time.monotonic()

            # prune minute-window
            minute_ago = now - 60
            while self._recent and self._recent[0] <= minute_ago:
                self._recent.popleft()

            # if too many in last minute, sleep until slot
            if len(self._recent) >= self.rpm:
                # compute sleep to oldest+60
                oldest = self._recent[0]
                to_sleep = (oldest + 60) - now + 0.01
                time.sleep(max(0.01, to_sleep))
                now = time.monotonic()
                # prune again
                minute_ago = now - 60
                while self._recent and self._recent[0] <= minute_ago:
                    self._recent.popleft()

            # record this request
            self._recent.append(now)
            self._last_req = now


# global limiter instance
_RATE_LIMITER = RateLimiter()


def _safe_request(session: requests.Session, method: str, url: str, max_retries: int = 4, backoff_factor: float = 1.0, **kwargs):
    """Perform a session.request while respecting rate limits and retrying on 429/403 with backoff.

    Returns the Response or raises the last exception.
    """
    attempt = 0
    while True:
        attempt += 1
        _RATE_LIMITER.wait()
        try:
            resp = session.request(method, url, **kwargs)
        except Exception as e:
            # network-level exception: decide whether to retry
            if attempt <= max_retries:
                sleep_for = backoff_factor * (2 ** (attempt - 1))
                time.sleep(sleep_for)
                continue
            raise

        if resp is None:
            if attempt <= max_retries:
                time.sleep(backoff_factor * (2 ** (attempt - 1)))
                continue
            return resp

        # If server indicates rate-limit or forbidden, back off and retry a few times.
        if resp.status_code in (429, 403):
            if attempt <= max_retries:
                # check Retry-After header first
                ra = resp.headers.get("Retry-After")
                if ra:
                    try:
                        ra_sec = int(float(ra))
                    except Exception:
                        ra_sec = None
                else:
                    ra_sec = None

                sleep_for = ra_sec if ra_sec is not None else (backoff_factor * (2 ** (attempt - 1)))
                # be conservative: add small jitter
                time.sleep(sleep_for + (0.1 * attempt))
                continue
            # max retries exhausted: return response to let caller handle
            return resp

        return resp


def safe_get(session: requests.Session, url: str, **kwargs):
    # apply a sensible default timeout if caller didn't provide one
    if "timeout" not in kwargs:
        kwargs["timeout"] = DEFAULT_REQ_TIMEOUT
    return _safe_request(session, "GET", url, **kwargs)


def safe_head(session: requests.Session, url: str, **kwargs):
    # HEAD checks can be shorter but still respect a reasonable default
    if "timeout" not in kwargs:
        kwargs["timeout"] = min(30, DEFAULT_REQ_TIMEOUT)
    return _safe_request(session, "HEAD", url, **kwargs)


def sanitize_filename(s: str) -> str:
    # Keep alphanumerics, dot, underscore, space and hyphen. Place hyphen at end of class to avoid range issues.
    s = re.sub(r"[^0-9A-Za-z._ -]+", "", (s or "")).strip()
    return s.replace(" ", "_")[:200] or "file"


def find_pdf_url(record: dict, session: requests.Session) -> Optional[str]:
    bib = record.get("bibjson") or {}
    candidates = []

    for link in (bib.get("link") or []) or []:
        url = link.get("url") or link.get("value") or link.get("href")
        fmt = (link.get("format") or link.get("type") or "").lower()
        if url:
            candidates.append((url, fmt))

    for link in (record.get("link") or []) or []:
        url = link.get("url") or link.get("value") or link.get("href")
        fmt = (link.get("format") or link.get("type") or "").lower()
        if url:
            candidates.append((url, fmt))

    for k in ("fulltext", "full_text", "fulltext_url", "full_text_url"):
        v = bib.get(k) or record.get(k)
        if isinstance(v, str) and v:
            candidates.append((v, ""))

    seen = set()
    for url, fmt in candidates:
        if not url or url in seen:
            continue
        seen.add(url)
        if url.lower().endswith(".pdf") or "pdf" in (fmt or ""):
            return url

    for url, _ in candidates[:6]:
        try:
            r = safe_head(session, url, headers=HEADERS, allow_redirects=True, timeout=min(30, DEFAULT_REQ_TIMEOUT))
            if r is None:
                continue
            ctype = r.headers.get("Content-Type", "")
            final = getattr(r, "url", url)
            if "pdf" in ctype.lower() or str(final).lower().endswith(".pdf"):
                return final
        except requests.exceptions.ReadTimeout:
            LOG.warning("HEAD timeout for %s; falling back to GET(accept=pdf)", url)
            # Try a couple of GET attempts with PDF accept header; use DEFAULT_REQ_TIMEOUT for overall request
            get_attempts = [DEFAULT_REQ_TIMEOUT, DEFAULT_REQ_TIMEOUT]
            for attempt_timeout in get_attempts:
                try:
                    headers = dict(HEADERS)
                    headers["Accept"] = "application/pdf"
                    r = safe_get(session, url, headers=headers, stream=True, timeout=attempt_timeout, allow_redirects=True)
                    if r is None:
                        break
                    ctype = r.headers.get("Content-Type", "")
                    final = getattr(r, "url", url)
                    if "pdf" in ctype.lower() or str(final).lower().endswith(".pdf"):
                        return final
                    break
                except requests.exceptions.ReadTimeout:
                    LOG.debug("GET attempt timed out for %s", url)
                    time.sleep(1)
                    continue
                except Exception:
                    break
        except Exception:
            continue

    for ident in (bib.get("identifier") or []):
        if isinstance(ident, dict) and (ident.get("type") or "").lower() == "doi":
            doi = ident.get("id")
            if doi:
                try:
                    doi_url = f"https://doi.org/{doi}"
                    headers = dict(HEADERS)
                    headers["Accept"] = "application/pdf"
                    r = safe_get(session, doi_url, headers=headers, timeout=DEFAULT_REQ_TIMEOUT, allow_redirects=True)
                    if r is None:
                        continue
                    ctype = r.headers.get("Content-Type", "")
                    if "pdf" in ctype.lower() or str(getattr(r, "url", "")).lower().endswith(".pdf"):
                        return getattr(r, "url", doi_url)
                except Exception:
                    pass

    return None


def generate_blob_name(record: dict, pdf_url: str) -> str:
    bib = record.get("bibjson") or {}
    identifiers = bib.get("identifier") or []
    article_id = None
    for ident in identifiers:
        if isinstance(ident, dict) and (ident.get("type") or "").lower() in ("doi", "id"):
            article_id = ident.get("id")
            break
    title = bib.get("title") or record.get("title") or ""
    title_part = sanitize_filename(title)[:120]
    if not article_id:
        article_id = hashlib.sha1(pdf_url.encode("utf-8")).hexdigest()[:12]
    return f"{article_id}_{title_part}.pdf"


def download_to_file(session: requests.Session, url: str, dest: Path) -> bool:
    try:
        r = safe_get(session, url, headers=HEADERS, stream=True, timeout=DEFAULT_REQ_TIMEOUT, allow_redirects=True)
        if r is None:
            LOG.warning("No response when downloading %s", url)
            return False
        try:
            r.raise_for_status()
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "wb") as fh:
                for chunk in r.iter_content(chunk_size=8192):
                    if chunk:
                        fh.write(chunk)
        finally:
            try:
                r.close()
            except Exception:
                pass
        return True
    except Exception as e:
        LOG.warning("Failed to download %s: %s", url, e)
        return False


def upload_blob(connection_string: str, container: str, blob_name: str, file_path: Path) -> bool:
    if BlobServiceClient is None:
        LOG.error("azure-storage-blob package not available; cannot upload")
        return False
    try:
        bsc = BlobServiceClient.from_connection_string(connection_string)
        container_client = bsc.get_container_client(container)
        try:
            container_client.create_container()
            LOG.info("Created container %s", container)
        except Exception:
            pass
        blob_client = container_client.get_blob_client(blob_name)
        try:
            if blob_client.exists():
                LOG.info("Blob %s exists, skipping", blob_name)
                return True
        except Exception:
            pass
        with open(file_path, "rb") as fh:
            blob_client.upload_blob(fh, overwrite=False, content_settings=ContentSettings(content_type="application/pdf"))
        LOG.info("Uploaded %s", blob_name)
        return True
    except Exception as e:
        LOG.error("Upload failed for %s: %s", blob_name, e)
        return False


def search_doaj(query: str, page_size: int, max_results: int, session: requests.Session) -> Generator[dict, None, None]:
    fetched = 0
    page = 1
    q = quote_plus(query)
    while fetched < max_results:
        url = f"{DOAJ_SEARCH_ENDPOINT}/{q}?page={page}&pageSize={page_size}"
        # Allow a few bounded retries for pagination errors (DOAJ may return 400/404 for out-of-range pages).
        # On 400/404, we attempt to reduce page_size and retry up to DOAJ_PAGE_RETRIES times before bailing.
        page_retry_attempts = 0
        max_page_retries = int(os.environ.get("DOAJ_PAGE_RETRIES", "4"))
        try:
            r = safe_get(session, url, headers=HEADERS, timeout=20)
            if r is None:
                LOG.error("No response from DOAJ for %s", url)
                return
            r.raise_for_status()
            data = r.json()
        except requests.HTTPError as e:
            status = getattr(e.response, "status_code", None)
            # If DOAJ responds 400/404 it can mean the page/offset is out of range.
            # If we were requesting larger page blocks, try reducing page_size and retry.
            # If page_size is already 1, treat this as end-of-results instead of an error
            # (prevents an upstream 400 from aborting the whole run when we've reached the last page).
            if status in (400, 404):
                # Try reducing page_size and retrying a few times before giving up.
                if page_size > 1 and page_retry_attempts < max_page_retries:
                    old = page_size
                    page_size = max(1, page_size // 2)
                    page_retry_attempts += 1
                    LOG.warning("DOAJ %s on page %s; reducing page_size %s->%s (attempt %s/%s)", status, page, old, page_size, page_retry_attempts, max_page_retries)
                    time.sleep(1)
                    # retry the same page with a smaller page_size
                    try:
                        # rebuild url with new page_size
                        url = f"{DOAJ_SEARCH_ENDPOINT}/{q}?page={page}&pageSize={page_size}"
                        r = safe_get(session, url, headers=HEADERS, timeout=20)
                        if r is None:
                            LOG.error("No response from DOAJ for %s", url)
                            return
                        r.raise_for_status()
                        data = r.json()
                    except requests.HTTPError:
                        # fallthrough to outer handler (will loop/retry until attempts exhausted)
                        continue
                    except Exception as inner_e:
                        LOG.error("DOAJ retry error: %s", inner_e)
                        return
                else:
                    # Either page_size==1 or we've exhausted retries: treat as end-of-results
                    LOG.info("DOAJ returned %s for page %s (likely out-of-range) or retries exhausted. Stopping pagination.", status, page)
                    return
            LOG.error("DOAJ request failed: %s", e)
            return
        except Exception as e:
            LOG.error("DOAJ request error: %s", e)
            return

        records = None
        for key in ("results", "records", "data"):
            if isinstance(data.get(key), list):
                records = data.get(key)
                break
        if records is None and isinstance(data, list):
            records = data
        if not records:
            LOG.debug("No records found on page %s", page)
            return

        for rec in records:
            yield rec
            fetched += 1
            if fetched >= max_results:
                return

        page += 1
        time.sleep(0.5)


def record_worker(rec, idx, params, tmp_dir_str, result_q):
    """Process a single record: detect PDF, download, optionally upload.
    Writes a JSON result dict to the result_q.
    """
    try:
        session = requests.Session()
        # Use configured retry policy (tunable via env vars)
        retry = Retry(total=RETRY_TOTAL, backoff_factor=RETRY_BACKOFF, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=["HEAD", "GET", "OPTIONS"])
        session.mount("https://", HTTPAdapter(max_retries=retry))
        session.mount("http://", HTTPAdapter(max_retries=retry))

        params = dict(params)
        dry_run = params.get('dry_run', False)
        connection_string = params.get('connection_string')
        container = params.get('container')
        delay = float(params.get('delay', 1.0))

        pdf_url = find_pdf_url(rec, session)
        if not pdf_url:
            result_q.put({"idx": idx, "status": "no_pdf", "msg": "no pdf url"})
            return

        blob_name = generate_blob_name(rec, pdf_url)
        local_path = Path(tmp_dir_str) / blob_name

        ok = download_to_file(session, pdf_url, local_path)
        if not ok:
            result_q.put({"idx": idx, "status": "download_failed", "msg": pdf_url})
            return

        if dry_run:
            try:
                local_path.unlink(missing_ok=True)
            except Exception:
                pass
            result_q.put({"idx": idx, "status": "dry_run_downloaded", "blob": blob_name})
            return

        # Pre-upload verification: check PDF magic bytes and minimum size to avoid false-positive uploads.
        try:
            min_bytes = int(os.environ.get("DOAJ_MIN_PDF_BYTES", "8192"))
        except Exception:
            min_bytes = 8192

        is_probably_pdf = False
        try:
            size = local_path.stat().st_size
            with open(local_path, "rb") as fh:
                head = fh.read(2048)
            # Basic checks: startswith %PDF or contains %PDF in first 2KB
            if head.startswith(b"%PDF") or b"%PDF" in head[:2048]:
                is_probably_pdf = True
        except Exception as e:
            LOG.warning("Pre-upload check failed for %s: %s", local_path, e)
            result_q.put({"idx": idx, "status": "precheck_error", "msg": str(e)})
            try:
                local_path.unlink(missing_ok=True)
            except Exception:
                pass
            return

        if not is_probably_pdf or (size is not None and size < min_bytes):
            note = []
            if not is_probably_pdf:
                note.append("no_pdf_magic")
            if size is not None and size < min_bytes:
                note.append(f"too_small({size}<{min_bytes})")
            reason = ",".join(note)
            LOG.info("Skipping upload for %s: %s", blob_name, reason)
            result_q.put({"idx": idx, "status": "skipped_not_pdf", "blob": blob_name, "note": reason, "size": size})
            try:
                local_path.unlink(missing_ok=True)
            except Exception:
                pass
            return

        uploaded = upload_blob(connection_string, container, blob_name, local_path)
        if uploaded:
            try:
                local_path.unlink(missing_ok=True)
            except Exception:
                pass
            result_q.put({"idx": idx, "status": "uploaded", "blob": blob_name})
            return
        else:
            result_q.put({"idx": idx, "status": "upload_failed", "blob": blob_name})
            return
    except Exception as e:
        try:
            result_q.put({"idx": idx, "status": "error", "msg": str(e)})
        except Exception:
            pass


def main(argv=None):
    # Allow overriding log level via environment variable for interactive runs
    # e.g. DOAJ_LOG_LEVEL=DEBUG
    env_level = os.environ.get("DOAJ_LOG_LEVEL", "INFO").upper()
    level = logging.DEBUG if env_level == "DEBUG" else logging.INFO
    setup_logging(level)
    parser = argparse.ArgumentParser(description="Download DOAJ PDFs and upload to Azure Blob Storage")
    parser.add_argument("--query", required=True)
    parser.add_argument("--container", default="doaj-pdfs")
    parser.add_argument("--connection-string", default=os.environ.get("AZURE_STORAGE_CONNECTION_STRING"))
    parser.add_argument("--max", type=int, default=100)
    parser.add_argument("--skip", type=int, default=0)
    parser.add_argument("--page-size", type=int, default=20)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--delay", type=float, default=1.0)
    parser.add_argument("--record-timeout", type=int, default=60, help="Per-record hard timeout in seconds")
    args = parser.parse_args(argv)

    if not args.connection_string and not args.dry_run:
        LOG.error("Azure connection string required unless --dry-run")
        sys.exit(1)

    session = requests.Session()
    # Use configured retry policy (tunable via env vars)
    retry = Retry(total=RETRY_TOTAL, backoff_factor=RETRY_BACKOFF, status_forcelist=[429, 500, 502, 503, 504], allowed_methods=["HEAD", "GET", "OPTIONS"])
    session.mount("https://", HTTPAdapter(max_retries=retry))
    session.mount("http://", HTTPAdapter(max_retries=retry))

    tmp_dir = Path("./tmp_downloads")
    tmp_dir.mkdir(parents=True, exist_ok=True)

    total_to_fetch = args.skip + args.max
    processed = 0
    idx = 0

    for rec in search_doaj(args.query, page_size=args.page_size, max_results=total_to_fetch, session=session):
        idx += 1
        if idx <= args.skip:
            continue
        processed += 1
        LOG.info("Processing %s/%s (record idx %s)", processed, args.max, idx)

        result_q = multiprocessing.Queue()
        params = {
            'dry_run': args.dry_run,
            'connection_string': args.connection_string,
            'container': args.container,
            'delay': args.delay
        }
        proc = multiprocessing.Process(target=record_worker, args=(rec, idx, params, str(tmp_dir), result_q))
        proc.start()
        proc.join(timeout=args.record_timeout)
        if proc.is_alive():
            LOG.warning("Record idx %s exceeded timeout (%ss); terminating worker", idx, args.record_timeout)
            try:
                proc.terminate()
            except Exception:
                pass
            proc.join()
            LOG.info("Skipped record idx %s due to timeout", idx)
        else:
            try:
                res = result_q.get_nowait()
                status = res.get('status')
                if status == 'no_pdf':
                    LOG.info("No PDF URL found for record idx %s", idx)
                elif status == 'download_failed':
                    LOG.warning("Download failed for record idx %s: %s", idx, res.get('msg'))
                elif status == 'dry_run_downloaded':
                    LOG.info("Dry-run: would upload blob %s", res.get('blob'))
                elif status == 'uploaded':
                    LOG.info("Uploaded blob %s for record idx %s", res.get('blob'), idx)
                elif status == 'upload_failed':
                    LOG.warning("Upload failed for record idx %s blob %s", idx, res.get('blob'))
                else:
                    LOG.warning("Record idx %s ended with status %s", idx, status)
            except Exception:
                LOG.warning("No result received from worker for record idx %s", idx)

        try:
            time.sleep(float(args.delay))
        except Exception:
            pass

    LOG.info("Completed processing. processed=%s", processed)


if __name__ == '__main__':
    main()
