#!/usr/bin/env python3
"""Diagnostic: for a DOAJ TOC, list top N candidate links and print HEAD/GET diagnostics.

Outputs:
 - index, url
 - HEAD: status_code, content-type, final URL, location header
 - If not PDF, then GET page (text) first 800 chars and list any .pdf hrefs found
"""
import re
import logging
import os
from pathlib import Path
from urllib.parse import urljoin

from download_and_upload import safe_head, safe_get, HEADERS
from toc_scrape_and_upload import find_candidate_links

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
LOG = logging.getLogger('diag')

PDF_HREF_RE = re.compile(r'href=["\']([^"\']+\.pdf)["\']', flags=re.I)


def diag_toc(toc_url: str, n: int = 10):
    import requests
    session = requests.Session()
    LOG.info('Fetching TOC %s', toc_url)
    r = safe_get(session, toc_url, headers=HEADERS, timeout=20)
    if r is None:
        LOG.error('No response for TOC')
        return
    html = r.text if hasattr(r, 'text') else ''
    candidates = find_candidate_links(toc_url, html)
    LOG.info('Found %s candidate links; showing top %s', len(candidates), n)
    seen = set()
    count = 0
    for url in candidates:
        if count >= n:
            break
        if url in seen:
            continue
        seen.add(url)
        count += 1
        print('\n--- Candidate %s ---' % count)
        print('URL:', url)
        try:
            h = safe_head(session, url, headers=HEADERS, allow_redirects=True, timeout=10)
            if h is None:
                print('HEAD: no response')
            else:
                sc = getattr(h, 'status_code', None)
                final = getattr(h, 'url', url)
                ctype = h.headers.get('Content-Type', '')
                loc = h.headers.get('Location')
                print('HEAD status:', sc)
                print('Content-Type:', ctype)
                print('Final URL:', final)
                if loc:
                    print('Location header:', loc)
                if h is not None and 'pdf' in (ctype or '').lower():
                    print('-> HEAD indicates PDF')
                    continue
        except Exception as e:
            print('HEAD error:', e)

        # GET page and inspect
        try:
            g = safe_get(session, url, headers=HEADERS, timeout=20, allow_redirects=True)
            if g is None:
                print('GET: no response')
                continue
            try:
                g.raise_for_status()
            except Exception:
                pass
            text = getattr(g, 'text', '') or ''
            snippet = text[:800].replace('\n', ' ')[:800]
            print('GET snippet (first 800 chars):')
            print(snippet)
            # find .pdf hrefs
            pdfs = PDF_HREF_RE.findall(text)
            if pdfs:
                print('Embedded .pdf hrefs found:')
                for p in pdfs[:10]:
                    print('-', urljoin(url, p))
            else:
                print('No embedded .pdf hrefs in HTML')
        except Exception as e:
            print('GET error:', e)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--toc-url', required=True)
    parser.add_argument('--n', type=int, default=10)
    args = parser.parse_args()
    diag_toc(args.toc_url, n=args.n)
