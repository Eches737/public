import logging
import os
import json

import requests
import azure.functions as func

# Azure Function Event Grid trigger that forwards blob-created events to a PDF-AI webhook.
# Set environment variable PDF_AI_WEBHOOK to the webhook URL for PDF-AI.

PDF_AI_WEBHOOK = os.environ.get('PDF_AI_WEBHOOK')


def main(event: func.EventGridEvent):
    try:
        data = event.get_json()
    except Exception:
        logging.exception('Failed to parse EventGridEvent JSON')
        return

    subject = event.subject
    event_type = event.event_type

    # For Storage.BlobCreated events the data.url property contains the blob URL
    blob_url = data.get('url') or (data.get('data') or {}).get('url')

    payload = {
        'eventType': event_type,
        'subject': subject,
        'blobUrl': blob_url,
        'raw': data,
    }

    webhook = PDF_AI_WEBHOOK or os.environ.get('PDF_AI_WEBHOOK')
    if not webhook:
        logging.error('PDF_AI_WEBHOOK not configured - cannot forward event')
        return

    try:
        resp = requests.post(webhook, json=payload, timeout=30)
        resp.raise_for_status()
        logging.info('Forwarded event to PDF-AI webhook, status=%s', resp.status_code)
    except Exception:
        logging.exception('Failed to forward event to PDF-AI webhook')

