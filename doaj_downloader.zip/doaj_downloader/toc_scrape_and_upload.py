#!/usr/bin/env python3
"""Scrape a DOAJ TOC page for article links / PDF links and upload PDFs to Azure.

This is a pragmatic fallback when the DOAJ API query path doesn't return records.
It uses the helper functions in `download_and_upload.py` for downloading & uploading.
"""
import argparse
import logging
import os
import re
from pathlib import Path
from urllib.parse import urljoin

import requests

from download_and_upload import safe_get, safe_head, download_to_file, upload_blob, HEADERS

LOG = logging.getLogger("doaj_toc_scraper")


def extract_hrefs(html: str):
    return re.findall(r'href=["\']([^"\']+)["\']', html, flags=re.I)


def find_candidate_links(base_url: str, html: str):
    hrefs = extract_hrefs(html)
    candidates = []
    # simple blacklist for static asset extensions we don't want to follow
    blacklist_ext = ('.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.css', '.js', '.woff', '.woff2', '.ttf', '.map', '.webmanifest', '.json', '.bmp')
    for h in hrefs:
        # ignore anchors, javascript and mailto/data links
        if not h or h.startswith('#') or h.startswith('javascript:') or h.startswith('mailto:') or h.startswith('data:'):
            continue
        full = urljoin(base_url, h)
        # only http(s)
        if not (full.startswith('http://') or full.startswith('https://')):
            continue
        # skip static asset extensions
        lower = full.lower()
        if any(lower.endswith(ext) for ext in blacklist_ext):
            continue
        # filter out many global DOAJ internal links (keep only those likely to be article lists or external publisher links)
        try:
            from urllib.parse import urlparse
            p = urlparse(full)
            host = p.netloc.lower()
            path = p.path.lower()
            if host.endswith('doaj.org'):
                # allow specific DOAJ paths that are likely to contain article links
                if not (path.startswith('/toc/') or '/articles' in path or '/journals' in path or '/search/articles' in path or '/search/journals' in path):
                    continue
        except Exception:
            pass

        candidates.append(full)

    # prefer candidate ordering: URLs that likely point to articles or PDFs first
    def score(u: str):
        s = 0
        lu = u.lower()
        if 'pdf' in lu:
            s += 50
        if '/article' in lu or '/articles' in lu or '/doi/' in lu or '/abs/' in lu or '/full' in lu or '/paper' in lu:
            s += 20
        # prefer same-domain links (relative) by giving small boost
        if base_url.split('/')[2] in u:
            s += 5
        return -s  # negative for sorting (higher score -> earlier)

    candidates = sorted(set(candidates), key=score)
    return candidates


def is_pdf_response(resp: requests.Response):
    if resp is None:
        return False
    ctype = resp.headers.get('Content-Type', '')
    if 'pdf' in ctype.lower():
        return True
    # fallback by url
    u = getattr(resp, 'url', '')
    if str(u).lower().endswith('.pdf'):
        return True
    return False


def process_toc(toc_url: str, max_articles: int, container: str, connection_string: str, dry_run: bool):
    session = requests.Session()
    LOG.info('Fetching TOC %s', toc_url)
    r = safe_get(session, toc_url, headers=HEADERS, timeout=20)
    if r is None:
        LOG.error('No response for toc %s', toc_url)
        return []
    try:
        r.raise_for_status()
    except Exception as e:
        LOG.error('TOC fetch failed: %s', e)
        return []

    html = r.text
    candidates = find_candidate_links(toc_url, html)
    LOG.info('Found %s candidate links on TOC', len(candidates))

    # If the TOC links mostly point to DOAJ internal pages (e.g. /toc/.../articles),
    # follow those pages and extract external publisher links as higher-priority candidates.
    expanded = []
    from urllib.parse import urlparse
    for link in candidates:
        expanded.append(link)
        try:
            p = urlparse(link)
            if p.netloc.endswith('doaj.org') and ('/toc/' in p.path or '/articles' in p.path):
                LOG.info('Following internal DOAJ page %s to extract publisher links', link)
                subr = safe_get(session, link, headers=HEADERS, timeout=20)
                if subr is None:
                    continue
                subhtml = getattr(subr, 'text', '') or ''
                subcands = find_candidate_links(link, subhtml)
                for s in subcands:
                    # prefer external (non-doaj) links found on the article list page
                    if s not in expanded:
                        expanded.append(s)
        except Exception:
            continue

    candidates = expanded

    uploaded = []
    tmp_dir = Path('./tmp_downloads')
    tmp_dir.mkdir(exist_ok=True)

    tried = set()
    for link in candidates:
        if len(uploaded) >= max_articles:
            break
        if link in tried:
            continue
        tried.add(link)

        # direct PDF link
        if link.lower().endswith('.pdf'):
            LOG.info('Direct PDF candidate: %s', link)
            ok = False
            try:
                resp = safe_head(session, link, headers=HEADERS, allow_redirects=True, timeout=10)
                if is_pdf_response(resp):
                    local = tmp_dir / link.split('/')[-1]
                    if download_to_file(session, link, local):
                        if not dry_run and connection_string:
                            blob_name = local.name
                            if upload_blob(connection_string, container, blob_name, local):
                                uploaded.append({'pdf_url': link, 'blob': blob_name})
                                try:
                                    local.unlink(missing_ok=True)
                                except Exception:
                                    pass
                        else:
                            uploaded.append({'pdf_url': link, 'blob': None})
                    continue
            except Exception:
                pass

        # otherwise try to HEAD the link to see if it resolves to PDF
        try:
            resp = safe_head(session, link, headers=HEADERS, allow_redirects=True, timeout=10)
            if is_pdf_response(resp):
                final = getattr(resp, 'url', link)
                LOG.info('HEAD indicates PDF for %s -> %s', link, final)
                local_name = final.split('/')[-1] or 'file.pdf'
                local = tmp_dir / local_name
                if download_to_file(session, final, local):
                    if not dry_run and connection_string:
                        blob_name = local.name
                        if upload_blob(connection_string, container, blob_name, local):
                            uploaded.append({'pdf_url': final, 'blob': blob_name})
                            try:
                                local.unlink(missing_ok=True)
                            except Exception:
                                pass
                    else:
                        uploaded.append({'pdf_url': final, 'blob': None})
                continue
        except Exception:
            pass

        # last resort: GET with Accept: application/pdf
        try:
            headers = dict(HEADERS)
            headers['Accept'] = 'application/pdf'
            resp = safe_get(session, link, headers=headers, stream=True, timeout=(5, 20), allow_redirects=True)
            if is_pdf_response(resp):
                final = getattr(resp, 'url', link)
                LOG.info('GET(accept=pdf) found PDF at %s', final)
                local_name = final.split('/')[-1] or 'file.pdf'
                local = tmp_dir / local_name
                # write stream
                try:
                    with open(local, 'wb') as fh:
                        for chunk in resp.iter_content(chunk_size=8192):
                            if chunk:
                                fh.write(chunk)
                finally:
                    try:
                        resp.close()
                    except Exception:
                        pass
                if not dry_run and connection_string:
                    blob_name = local.name
                    if upload_blob(connection_string, container, blob_name, local):
                        uploaded.append({'pdf_url': final, 'blob': blob_name})
                        try:
                            local.unlink(missing_ok=True)
                        except Exception:
                            pass
                else:
                    uploaded.append({'pdf_url': final, 'blob': None})
                continue
        except Exception:
            pass

        # if still not found, fetch the page HTML and look for PDF hrefs inside
        try:
            page = safe_get(session, link, headers=HEADERS, timeout=20)
            if page is not None:
                try:
                    page.raise_for_status()
                except Exception:
                    page_text = getattr(page, 'text', '')
                else:
                    page_text = page.text
                # search for hrefs that end with .pdf
                pdf_hrefs = re.findall(r'href=["\']([^"\']+\.pdf)["\']', page_text, flags=re.I)
                for ph in pdf_hrefs:
                    final_pdf = urljoin(link, ph)
                    LOG.info('Found embedded PDF link %s in %s', final_pdf, link)
                    local_name = final_pdf.split('/')[-1] or 'file.pdf'
                    local = tmp_dir / local_name
                    if download_to_file(session, final_pdf, local):
                        if not dry_run and connection_string:
                            blob_name = local.name
                            if upload_blob(connection_string, container, blob_name, local):
                                uploaded.append({'pdf_url': final_pdf, 'blob': blob_name})
                                try:
                                    local.unlink(missing_ok=True)
                                except Exception:
                                    pass
                        else:
                            uploaded.append({'pdf_url': final_pdf, 'blob': None})
                        break
        except Exception:
            pass

    LOG.info('TOC processing complete: uploaded=%s', len(uploaded))
    return uploaded


def main(argv=None):
    import argparse
    parser = argparse.ArgumentParser(description='Scrape DOAJ TOC page for PDFs and upload')
    parser.add_argument('--toc-url', required=True)
    parser.add_argument('--max', type=int, default=5)
    parser.add_argument('--container', default='doaj-pdfs')
    parser.add_argument('--connection-string', default=os.environ.get('AZURE_STORAGE_CONNECTION_STRING'))
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args(argv)

    level = logging.INFO
    logging.basicConfig(level=level, format='%(asctime)s %(levelname)s: %(message)s')

    if not args.connection_string and not args.dry_run:
        LOG.error('Azure connection string required unless --dry-run')
        return

    res = process_toc(args.toc_url, max_articles=args.max, container=args.container, connection_string=args.connection_string, dry_run=args.dry_run)
    for r in res:
        print(r)


if __name__ == '__main__':
    main()
