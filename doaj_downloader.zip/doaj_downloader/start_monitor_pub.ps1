$log = Join-Path $PSScriptRoot 'doaj_run_10000.log'
$out = Join-Path $PSScriptRoot 'doaj_monitor_pub.log'
while ($true) {
    try {
        if (Test-Path $log) {
            $uploaded = (Select-String -Path $log -Pattern 'Uploaded blob' -ErrorAction SilentlyContinue | Measure-Object).Count
            $nopdf = (Select-String -Path $log -Pattern 'No PDF URL found' -ErrorAction SilentlyContinue | Measure-Object).Count
            $timeout = (Select-String -Path $log -Pattern 'exceeded timeout' -ErrorAction SilentlyContinue | Measure-Object).Count
            $skipped = (Select-String -Path $log -Pattern 'skipped_not_pdf' -ErrorAction SilentlyContinue | Measure-Object).Count
            $line = "$(Get-Date -Format o) uploaded:$uploaded; no_pdf:$nopdf; timeout:$timeout; skipped_not_pdf:$skipped"
            $line | Out-File -FilePath $out -Append -Encoding utf8
        }
    } catch {
        # swallow transient errors and continue
    }
    Start-Sleep -Seconds 60
}
