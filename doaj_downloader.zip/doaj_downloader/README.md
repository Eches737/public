DOAJ PDF downloader + Azure uploader

What this does
- Uses the DOAJ search API to find article records matching a query.
- Tries to discover PDF links in article metadata.
- Downloads found PDFs and uploads them to an Azure Blob container.

Requirements
- Python 3.8+
- An Azure Storage account and a connection string (set with env var AZURE_STORAGE_CONNECTION_STRING or pass `--connection-string`).
- DOAJ is an open-access directory; ensure you respect DOAJ terms of service and robots.txt for automated downloads.

Install

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r doaj_downloader\requirements.txt
```

Usage

```powershell
# dry run - list found PDF URLs without downloading
python doaj_downloader\download_and_upload.py --query "issn:1234-5678" --max 20 --dry-run

# actual download + upload (uses AZURE_STORAGE_CONNECTION_STRING environment variable)
$env:AZURE_STORAGE_CONNECTION_STRING = "DefaultEndpointsProtocol=..."
python doaj_downloader\download_and_upload.py --query "issn:1234-5678" --max 20 --container doaj-pdfs

# or pass connection string directly
python doaj_downloader\download_and_upload.py --query "issn:1234-5678" --connection-string "DefaultEndpointsProtocol=..." --container doaj-pdfs
```

Parameters
- `--query`: DOAJ search query. You can use keyword queries or fielded queries such as `issn:1234-5678`.
- `--max`: maximum articles to process.
- `--container`: the blob container to upload PDFs into. The script will attempt to create it if missing.
- `--delay`: seconds to wait between downloads (politeness).

Notes and next steps
- The script uses heuristics to find PDF URLs. If your target journals have a consistent pattern, we can add a specialized extractor for better accuracy.
- If you want to store metadata (DOAJ record JSON) alongside PDFs, I can update the script to upload a .json sidecar file.
- For production: consider adding retries with exponential backoff, logging, and more robust error handling.
