#!/usr/bin/env python3
import os
import sys
import argparse
from datetime import timezone

try:
    from azure.storage.blob import BlobServiceClient
except Exception as e:
    print("ERROR: azure-storage-blob not available:", e)
    sys.exit(2)

parser = argparse.ArgumentParser(description='List recent blobs in a container')
parser.add_argument('--container', required=True)
parser.add_argument('--limit', type=int, default=20)
args = parser.parse_args()

conn = os.environ.get('AZURE_STORAGE_CONNECTION_STRING')
if not conn:
    print('ERROR: AZURE_STORAGE_CONNECTION_STRING not set in environment')
    sys.exit(3)

bsc = BlobServiceClient.from_connection_string(conn)
container_client = bsc.get_container_client(args.container)

blobs = list(container_client.list_blobs())
# sort by last_modified desc
blobs.sort(key=lambda b: getattr(b, 'last_modified', None) or 0, reverse=True)

print(f"Found {len(blobs)} blobs in container {args.container}")
print(f"Showing top {args.limit} by last_modified:\n")
print(f"{'#':>3}  {'name':<80}  {'size(bytes)':>12}  {'last_modified'}")
for i, b in enumerate(blobs[: args.limit], start=1):
    lm = getattr(b, 'last_modified', None)
    if lm and lm.tzinfo is None:
        lm = lm.replace(tzinfo=timezone.utc)
    print(f"{i:3d}. {b.name:<80.80}  {getattr(b,'size',0):12d}  {lm}")

sys.exit(0)
