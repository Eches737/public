import os
import datetime
from azure.storage.blob import BlobServiceClient

conn = os.environ.get('AZURE_STORAGE_CONNECTION_STRING')
if not conn:
    print('NO_CONN')
    raise SystemExit(1)

container = 'doaj-pdfs'
bs = BlobServiceClient.from_connection_string(conn)
cc = bs.get_container_client(container)

now = datetime.datetime.utcnow().replace(tzinfo=None)
cutoff = now - datetime.timedelta(hours=1)  # 최근 1시간
print('NOW', now.isoformat())
print('CUTOFF', cutoff.isoformat())
found = 0
for b in cc.list_blobs():
    lm = b.last_modified
    if not lm:
        continue
    if lm.tzinfo is not None:
        lm_utc = lm.astimezone(datetime.timezone.utc).replace(tzinfo=None)
    else:
        lm_utc = lm
    if lm_utc >= cutoff:
        print(lm_utc.isoformat(), b.name)
        found += 1
print('FOUND', found)
