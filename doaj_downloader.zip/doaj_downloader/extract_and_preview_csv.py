#!/usr/bin/env python3
"""Extract DOAJ TOC URLs from journal CSV and preview journals with Number of Article Records > 0.

Outputs:
 - prints a short summary and first 20 selected rows
 - writes `selected_tocs.json` with list of {title, doaj_toc, count}
"""
import csv
import json
from pathlib import Path

csv_path = Path(__file__).parent / "journalcsv__doaj_20251108_0129_utf8.csv"
out_path = Path(__file__).parent / "selected_tocs.json"

rows = []
with open(csv_path, "r", encoding="utf-8-sig", newline="") as fh:
    reader = csv.DictReader(fh)
    # find the exact keys we need
    headers = reader.fieldnames or []
    key_toc = None
    key_count = None
    key_title = None
    for h in headers:
        nh = h.strip().lower()
        if nh == "url in doaj":
            key_toc = h
        if nh == "number of article records":
            key_count = h
        if nh == "journal title":
            key_title = h
    if key_toc is None or key_count is None:
        print("ERROR: couldn't find required columns. headers=", headers)
        raise SystemExit(2)

    for r in reader:
        toc = (r.get(key_toc) or "").strip()
        cnt_raw = (r.get(key_count) or "").strip()
        title = (r.get(key_title) or "").strip()
        try:
            cnt = int(cnt_raw) if cnt_raw else 0
        except Exception:
            # try to remove non-digits
            import re
            m = re.search(r"(\d+)", cnt_raw or "")
            cnt = int(m.group(1)) if m else 0
        if toc and cnt > 0:
            rows.append({"title": title, "doaj_toc": toc, "count": cnt})

# sort by count desc
rows.sort(key=lambda x: -x["count"]) 

print(f"Found {len(rows)} journals with Number of Article Records > 0")
print("Preview (first 20):")
for i, r in enumerate(rows[:20], 1):
    print(f"{i}. {r['title']} | {r['doaj_toc']} | articles={r['count']}")

with open(out_path, "w", encoding="utf-8") as fh:
    json.dump(rows, fh, ensure_ascii=False, indent=2)

print(f"Wrote {out_path} with {len(rows)} items")
