$v = [Environment]::GetEnvironmentVariable('AZURE_STORAGE_CONNECTION_STRING','Process')
if (-not $v) { Write-Output 'NOTSET' }
elseif ($v -match 'DefaultEndpointsProtocol=|AccountName=|AccountKey=') { Write-Output 'SET' }
else { Write-Output 'PRESENT-BUT-MALFORMED' }
